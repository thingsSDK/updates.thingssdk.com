"use strict";

const log = require("./back-end/logger");

// Parity errors:
// options.c_iflag = IGNPAR;
// options.c_cflag |= HUPCL;  //drop DTR (i.e. hangup) on close

const RomComm = require("./back-end/rom_comm");


var esp = new RomComm({
    portName: "/dev/cu.SLAB_USBtoUART",
    baudRate: 115200,
});

esp.open().then((result) => {
    log.info("ESP is open", result);
    esp.flashAddressFromFile(0x0000, "/Users/craig/Code/jsot/esptool/esp-latest/boot_v1.4(b1).bin")
        .then((result) => esp.flashAddressFromFile(0x1000, "/Users/craig/Code/jsot/esptool/esp-latest/espruino_esp8266_user1.bin"))
        .then((result) => esp.flashAddressFromFile(0x3FC000, "/Users/craig/Code/jsot/esptool/esp-latest/esp_init_data_default.bin"))
        .then((result) => esp.flashAddressFromFile(0x3FE000, "/Users/craig/Code/jsot/esptool/esp-latest/blank.bin"))
        .then((result) => esp.close())
        .then((result) => log.info("YESSSS!!!!!", result));
}).catch((error) => {
    log.error("Damnit!", error);
});